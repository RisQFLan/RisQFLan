
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Bypassing802 implements IAtreeModelBuilder {
	
	public Bypassing802(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode A = new AttackNode("A");
		model.addAttackNodeDefinition(A);
		AttackNode B = new AttackNode("B");
		model.addAttackNodeDefinition(B);
		AttackNode C = new AttackNode("C");
		model.addAttackNodeDefinition(C);
		AttackNode D = new AttackNode("D");
		model.addAttackNodeDefinition(D);
		AttackNode E = new AttackNode("E");
		model.addAttackNodeDefinition(E);
		AttackNode F = new AttackNode("F");
		model.addAttackNodeDefinition(F);
		AttackNode a = new AttackNode("a");
		model.addAttackNodeDefinition(a);
		AttackNode b = new AttackNode("b");
		model.addAttackNodeDefinition(b);
		AttackNode c = new AttackNode("c");
		model.addAttackNodeDefinition(c);
		AttackNode d = new AttackNode("d");
		model.addAttackNodeDefinition(d);
		AttackNode e = new AttackNode("e");
		model.addAttackNodeDefinition(e);
		AttackNode f = new AttackNode("f");
		model.addAttackNodeDefinition(f);
		AttackNode g = new AttackNode("g");
		model.addAttackNodeDefinition(g);
		AttackNode fg = new AttackNode("fg");
		model.addAttackNodeDefinition(fg);
		
		
		
		
		/////////////////
		////Relations////
		/////////////////
		LinkedHashMap<String,Set<String>> orRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> andRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> knRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> oandRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,List<String>> childrenMap = new LinkedHashMap<>();
		LinkedHashMap<String,Integer> knChildren = new LinkedHashMap<>();
		childrenMap.put("set0",Arrays.asList("B","E"));
		childrenMap.put("set1",Arrays.asList("C","d"));
		childrenMap.put("set2",Arrays.asList("D","b","c"));
		childrenMap.put("set3",Arrays.asList("a"));
		childrenMap.put("set4",Arrays.asList("F","fg"));
		childrenMap.put("set5",Arrays.asList("f","g"));
		childrenMap.put("set6",Arrays.asList("e"));
		orRelations.put("A",new HashSet<>(Arrays.asList("set0")));
		orRelations.put("F",new HashSet<>(Arrays.asList("set6")));
		andRelations.put("D",new HashSet<>(Arrays.asList("set3")));
		andRelations.put("fg",new HashSet<>(Arrays.asList("set5")));
		oandRelations.put("B",new HashSet<>(Arrays.asList("set1")));
		oandRelations.put("C",new HashSet<>(Arrays.asList("set2")));
		oandRelations.put("E",new HashSet<>(Arrays.asList("set4")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker Best = new Attacker ("Best");
		model.addAttacker(Best);
		Attacker AverageA = new Attacker ("AverageA");
		model.addAttacker(AverageA);
		Attacker AverageB = new Attacker ("AverageB");
		model.addAttacker(AverageB);
		Attacker Worst = new Attacker ("Worst");
		model.addAttacker(Worst);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		
		///////////////
		////Actions////
		///////////////
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState W0 = new ProcessState("W0");
		model.setInitialState(W0);
		W0.addTransition(new ProcessTransition(1.0,new AddAction(A),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(2.0,new AddAction(B),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(3.0,new AddAction(C),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(4.0,new AddAction(D),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(5.0,new AddAction(E),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(6.0,new AddAction(F),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(7.0,new AddAction(a),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(8.0,new AddAction(b),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(9.0,new AddAction(c),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(d),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(11.0,new AddAction(e),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(12.0,new AddAction(f),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(13.0,new AddAction(g),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(14.0,new AddAction(fg),W0,new SideEffect[]{},new TrueConstraint()));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(Worst,Arrays.asList());
		
		return model;
	}
}
