
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Bypassing802debug implements IAtreeModelBuilder {
	
	public Bypassing802debug(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode A = new AttackNode("A");
		model.addAttackNodeDefinition(A);
		AttackNode F = new AttackNode("F");
		model.addAttackNodeDefinition(F);
		AttackNode fg = new AttackNode("fg");
		model.addAttackNodeDefinition(fg);
		
		
		
		
		/////////////////
		////Relations////
		/////////////////
		LinkedHashMap<String,Set<String>> orRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> andRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> knRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> oandRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,List<String>> childrenMap = new LinkedHashMap<>();
		LinkedHashMap<String,Integer> knChildren = new LinkedHashMap<>();
		childrenMap.put("set0",Arrays.asList("F","fg"));
		oandRelations.put("A",new HashSet<>(Arrays.asList("set0")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker Best = new Attacker ("Best");
		model.addAttacker(Best);
		Attacker AverageA = new Attacker ("AverageA");
		model.addAttacker(AverageA);
		Attacker AverageB = new Attacker ("AverageB");
		model.addAttacker(AverageB);
		Attacker Worst = new Attacker ("Worst");
		model.addAttacker(Worst);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		
		///////////////
		////Actions////
		///////////////
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState W0 = new ProcessState("W0");
		model.setInitialState(W0);
		W0.addTransition(new ProcessTransition(1.0,new AddAction(A),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(6.0,new AddAction(F),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(14.0,new AddAction(fg),W0,new SideEffect[]{},new TrueConstraint()));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(Worst,Arrays.asList());
		
		return model;
	}
}
