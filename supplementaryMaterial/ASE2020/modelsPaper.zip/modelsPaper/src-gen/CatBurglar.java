
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CatBurglar implements IAtreeModelBuilder {
	
	public CatBurglar(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode BurgleHouse = new AttackNode("BurgleHouse");
		model.addAttackNodeDefinition(BurgleHouse);
		AttackNode EnterHouse = new AttackNode("EnterHouse");
		model.addAttackNodeDefinition(EnterHouse);
		AttackNode PenetrateHouse1 = new AttackNode("PenetrateHouse1");
		model.addAttackNodeDefinition(PenetrateHouse1);
		AttackNode GarageAttack = new AttackNode("GarageAttack");
		model.addAttackNodeDefinition(GarageAttack);
		AttackNode EnterGarage = new AttackNode("EnterGarage");
		model.addAttackNodeDefinition(EnterGarage);
		AttackNode OpenCarDoor = new AttackNode("OpenCarDoor");
		model.addAttackNodeDefinition(OpenCarDoor);
		AttackNode SendDoorOpenerCode = new AttackNode("SendDoorOpenerCode");
		model.addAttackNodeDefinition(SendDoorOpenerCode);
		AttackNode PenetrateHouse2 = new AttackNode("PenetrateHouse2");
		model.addAttackNodeDefinition(PenetrateHouse2);
		AttackNode OpenPassageDoor = new AttackNode("OpenPassageDoor");
		model.addAttackNodeDefinition(OpenPassageDoor);
		AttackNode WalkUpToHouse = new AttackNode("WalkUpToHouse");
		model.addAttackNodeDefinition(WalkUpToHouse);
		AttackNode EavesdropAndReplayOpenerCode = new AttackNode("EavesdropAndReplayOpenerCode");
		model.addAttackNodeDefinition(EavesdropAndReplayOpenerCode);
		AttackNode PickLock = new AttackNode("PickLock");
		model.addAttackNodeDefinition(PickLock);
		
		
		
		
		/////////////////
		////Relations////
		/////////////////
		LinkedHashMap<String,Set<String>> orRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> andRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> knRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> oandRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,List<String>> childrenMap = new LinkedHashMap<>();
		LinkedHashMap<String,Integer> knChildren = new LinkedHashMap<>();
		childrenMap.put("set0",Arrays.asList("EnterHouse"));
		childrenMap.put("set1",Arrays.asList("WalkUpToHouse","PenetrateHouse1"));
		childrenMap.put("set2",Arrays.asList("GarageAttack"));
		childrenMap.put("set3",Arrays.asList("EnterGarage","PenetrateHouse2"));
		childrenMap.put("set4",Arrays.asList("OpenCarDoor"));
		childrenMap.put("set5",Arrays.asList("SendDoorOpenerCode"));
		childrenMap.put("set6",Arrays.asList("EavesdropAndReplayOpenerCode"));
		childrenMap.put("set7",Arrays.asList("OpenPassageDoor"));
		childrenMap.put("set8",Arrays.asList("PickLock"));
		orRelations.put("BurgleHouse",new HashSet<>(Arrays.asList("set0")));
		orRelations.put("PenetrateHouse1",new HashSet<>(Arrays.asList("set2")));
		orRelations.put("EnterGarage",new HashSet<>(Arrays.asList("set4")));
		orRelations.put("OpenCarDoor",new HashSet<>(Arrays.asList("set5")));
		orRelations.put("SendDoorOpenerCode",new HashSet<>(Arrays.asList("set6")));
		orRelations.put("PenetrateHouse2",new HashSet<>(Arrays.asList("set7")));
		orRelations.put("OpenPassageDoor",new HashSet<>(Arrays.asList("set8")));
		andRelations.put("EnterHouse",new HashSet<>(Arrays.asList("set1")));
		andRelations.put("GarageAttack",new HashSet<>(Arrays.asList("set3")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		AttributeDef Noticeability = new AttributeDef("Noticeability");
		model.addAttributeDef(Noticeability);
		Noticeability.setNodeValue(WalkUpToHouse,1.0);
		Noticeability.setNodeValue(EavesdropAndReplayOpenerCode,5.0);
		Noticeability.setNodeValue(PickLock,2.0);
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker Best = new Attacker ("Best");
		model.addAttacker(Best);
		Attacker AverageA = new Attacker ("AverageA");
		model.addAttacker(AverageA);
		Attacker AverageB = new Attacker ("AverageB");
		model.addAttacker(AverageB);
		Attacker Worst = new Attacker ("Worst");
		model.addAttacker(Worst);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		
		///////////////
		////Actions////
		///////////////
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState W0 = new ProcessState("W0");
		model.setInitialState(W0);
		W0.addTransition(new ProcessTransition(1.0,new AddAction(BurgleHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(EnterHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(PenetrateHouse1),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(GarageAttack),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(EnterGarage),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(OpenCarDoor),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(SendDoorOpenerCode),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(PenetrateHouse2),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(OpenPassageDoor),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(WalkUpToHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(PickLock),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(EavesdropAndReplayOpenerCode),W0,new SideEffect[]{},new TrueConstraint()));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(Worst,Arrays.asList());
		
		return model;
	}
}
