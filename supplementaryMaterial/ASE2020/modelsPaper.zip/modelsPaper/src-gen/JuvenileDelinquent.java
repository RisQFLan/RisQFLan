
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class JuvenileDelinquent implements IAtreeModelBuilder {
	
	public JuvenileDelinquent(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode BurgleHouse = new AttackNode("BurgleHouse");
		model.addAttackNodeDefinition(BurgleHouse);
		AttackNode EnterHouse = new AttackNode("EnterHouse");
		model.addAttackNodeDefinition(EnterHouse);
		AttackNode PenetrateHouse1 = new AttackNode("PenetrateHouse1");
		model.addAttackNodeDefinition(PenetrateHouse1);
		AttackNode OpenPassageDoor1 = new AttackNode("OpenPassageDoor1");
		model.addAttackNodeDefinition(OpenPassageDoor1);
		AttackNode EnterViaWindow = new AttackNode("EnterViaWindow");
		model.addAttackNodeDefinition(EnterViaWindow);
		AttackNode GarageAttack = new AttackNode("GarageAttack");
		model.addAttackNodeDefinition(GarageAttack);
		AttackNode EnterGarage = new AttackNode("EnterGarage");
		model.addAttackNodeDefinition(EnterGarage);
		AttackNode OpenCarDoor = new AttackNode("OpenCarDoor");
		model.addAttackNodeDefinition(OpenCarDoor);
		AttackNode SendDoorOpenerCode = new AttackNode("SendDoorOpenerCode");
		model.addAttackNodeDefinition(SendDoorOpenerCode);
		AttackNode PenetrateHouse2 = new AttackNode("PenetrateHouse2");
		model.addAttackNodeDefinition(PenetrateHouse2);
		AttackNode OpenPassageDoor2 = new AttackNode("OpenPassageDoor2");
		model.addAttackNodeDefinition(OpenPassageDoor2);
		AttackNode WalkUpToHouse = new AttackNode("WalkUpToHouse");
		model.addAttackNodeDefinition(WalkUpToHouse);
		AttackNode BreakDownDoor = new AttackNode("BreakDownDoor");
		model.addAttackNodeDefinition(BreakDownDoor);
		AttackNode BreakGlass = new AttackNode("BreakGlass");
		model.addAttackNodeDefinition(BreakGlass);
		AttackNode StealOpenerFromCar = new AttackNode("StealOpenerFromCar");
		model.addAttackNodeDefinition(StealOpenerFromCar);
		AttackNode BreakDownPassageDoor = new AttackNode("BreakDownPassageDoor");
		model.addAttackNodeDefinition(BreakDownPassageDoor);
		
		
		
		
		/////////////////
		////Relations////
		/////////////////
		LinkedHashMap<String,Set<String>> orRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> andRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> knRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> oandRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,List<String>> childrenMap = new LinkedHashMap<>();
		LinkedHashMap<String,Integer> knChildren = new LinkedHashMap<>();
		childrenMap.put("set0",Arrays.asList("EnterHouse"));
		childrenMap.put("set1",Arrays.asList("WalkUpToHouse","PenetrateHouse1"));
		childrenMap.put("set2",Arrays.asList("OpenPassageDoor1","EnterViaWindow","GarageAttack"));
		childrenMap.put("set3",Arrays.asList("BreakDownDoor"));
		childrenMap.put("set4",Arrays.asList("BreakGlass"));
		childrenMap.put("set5",Arrays.asList("EnterGarage","PenetrateHouse2"));
		childrenMap.put("set6",Arrays.asList("OpenCarDoor"));
		childrenMap.put("set7",Arrays.asList("SendDoorOpenerCode"));
		childrenMap.put("set8",Arrays.asList("StealOpenerFromCar"));
		childrenMap.put("set9",Arrays.asList("OpenPassageDoor2"));
		childrenMap.put("set10",Arrays.asList("BreakDownPassageDoor"));
		orRelations.put("BurgleHouse",new HashSet<>(Arrays.asList("set0")));
		orRelations.put("PenetrateHouse1",new HashSet<>(Arrays.asList("set2")));
		orRelations.put("OpenPassageDoor1",new HashSet<>(Arrays.asList("set3")));
		orRelations.put("EnterViaWindow",new HashSet<>(Arrays.asList("set4")));
		orRelations.put("EnterGarage",new HashSet<>(Arrays.asList("set6")));
		orRelations.put("OpenCarDoor",new HashSet<>(Arrays.asList("set7")));
		orRelations.put("SendDoorOpenerCode",new HashSet<>(Arrays.asList("set8")));
		orRelations.put("PenetrateHouse2",new HashSet<>(Arrays.asList("set9")));
		orRelations.put("OpenPassageDoor2",new HashSet<>(Arrays.asList("set10")));
		andRelations.put("EnterHouse",new HashSet<>(Arrays.asList("set1")));
		andRelations.put("GarageAttack",new HashSet<>(Arrays.asList("set5")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		AttributeDef Noticeability = new AttributeDef("Noticeability");
		model.addAttributeDef(Noticeability);
		Noticeability.setNodeValue(WalkUpToHouse,0.1);
		Noticeability.setNodeValue(BreakDownDoor,3.0);
		Noticeability.setNodeValue(BreakGlass,3.0);
		Noticeability.setNodeValue(StealOpenerFromCar,2.0);
		Noticeability.setNodeValue(BreakDownPassageDoor,1.0);
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker Best = new Attacker ("Best");
		model.addAttacker(Best);
		Attacker AverageA = new Attacker ("AverageA");
		model.addAttacker(AverageA);
		Attacker AverageB = new Attacker ("AverageB");
		model.addAttacker(AverageB);
		Attacker Worst = new Attacker ("Worst");
		model.addAttacker(Worst);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		
		///////////////
		////Actions////
		///////////////
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState W0 = new ProcessState("W0");
		model.setInitialState(W0);
		W0.addTransition(new ProcessTransition(1.0,new AddAction(BurgleHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(EnterHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(PenetrateHouse1),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(OpenPassageDoor1),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(EnterViaWindow),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(GarageAttack),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(EnterGarage),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(OpenCarDoor),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(SendDoorOpenerCode),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(PenetrateHouse2),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(1.0,new AddAction(OpenPassageDoor2),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(WalkUpToHouse),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(BreakDownDoor),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(BreakGlass),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(StealOpenerFromCar),W0,new SideEffect[]{},new TrueConstraint()));
		W0.addTransition(new ProcessTransition(10.0,new AddAction(BreakDownPassageDoor),W0,new SideEffect[]{},new TrueConstraint()));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(Worst,Arrays.asList());
		
		return model;
	}
}
