
import atree.core.attacker.*;
import atree.core.attributes.*;
import atree.core.model.*;
import atree.core.nodes.*;
import atree.core.processes.*;
import atree.core.processes.actions.*;
import atree.core.processes.constraints.*;
import atree.core.variables.*;

import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BGP implements IAtreeModelBuilder {
	
	public BGP(){
		System.out.println("Model builder instantiated");
	}
	public AtreeModel createModel(){
		
		AtreeModel model = new AtreeModel();		
		
		//////////////////
		/////Variables////
		//////////////////
		
		
		/////////////
		////Nodes////
		/////////////
		AttackNode G = new AttackNode("G");
		model.addAttackNodeDefinition(G);
		AttackNode A1 = new AttackNode("A1");
		model.addAttackNodeDefinition(A1);
		AttackNode A111 = new AttackNode("A111");
		model.addAttackNodeDefinition(A111);
		AttackNode A112 = new AttackNode("A112");
		model.addAttackNodeDefinition(A112);
		AttackNode A1121 = new AttackNode("A1121");
		model.addAttackNodeDefinition(A1121);
		AttackNode A1122 = new AttackNode("A1122");
		model.addAttackNodeDefinition(A1122);
		AttackNode A1123 = new AttackNode("A1123");
		model.addAttackNodeDefinition(A1123);
		AttackNode A12 = new AttackNode("A12");
		model.addAttackNodeDefinition(A12);
		AttackNode A2 = new AttackNode("A2");
		model.addAttackNodeDefinition(A2);
		AttackNode OR1 = new AttackNode("OR1");
		model.addAttackNodeDefinition(OR1);
		
		DefenseNode M12 = new DefenseNode("M12");
		model.addDefenseNodeDefinition(M12);
		DefenseNode M1 = new DefenseNode("M1");
		model.addDefenseNodeDefinition(M1);
		DefenseNode M2 = new DefenseNode("M2");
		model.addDefenseNodeDefinition(M2);
		
		CountermeasureNode D12 = new CountermeasureNode("D12");
		model.addCountermeasureNodeDefinition(D12,Arrays.asList(A12));
		CountermeasureNode D1 = new CountermeasureNode("D1");
		model.addCountermeasureNodeDefinition(D1,Arrays.asList(A1));
		CountermeasureNode D2 = new CountermeasureNode("D2");
		model.addCountermeasureNodeDefinition(D2,Arrays.asList(A2));
		
		
		/////////////////
		////Relations////
		/////////////////
		LinkedHashMap<String,Set<String>> orRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> andRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> knRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,Set<String>> oandRelations = new LinkedHashMap<>(); 
		LinkedHashMap<String,List<String>> childrenMap = new LinkedHashMap<>();
		LinkedHashMap<String,Integer> knChildren = new LinkedHashMap<>();
		childrenMap.put("set0",Arrays.asList("A1","A2"));
		childrenMap.put("set1",Arrays.asList("OR1","A12"));
		childrenMap.put("set2",Arrays.asList("A111","A112"));
		childrenMap.put("set3",Arrays.asList("A1121","A1122","A1123"));
		childrenMap.put("set4",Arrays.asList("M12"));
		childrenMap.put("set5",Arrays.asList("M1"));
		childrenMap.put("set6",Arrays.asList("M2"));
		orRelations.put("G",new HashSet<>(Arrays.asList("set0")));
		orRelations.put("OR1",new HashSet<>(Arrays.asList("set2")));
		orRelations.put("A112",new HashSet<>(Arrays.asList("set3")));
		andRelations.put("A1",new HashSet<>(Arrays.asList("set1")));
		andRelations.put("D12",new HashSet<>(Arrays.asList("set4")));
		andRelations.put("D1",new HashSet<>(Arrays.asList("set5")));
		andRelations.put("D2",new HashSet<>(Arrays.asList("set6")));
		model.addAllRelations(orRelations,andRelations,knRelations,oandRelations,childrenMap,knChildren);
		
		//////////////////
		////Attributes////
		//////////////////
		
		/////////////////
		////Attackers////
		/////////////////
		Attacker Random = new Attacker ("Random");
		model.addAttacker(Random);
		Attacker Sneaky = new Attacker ("Sneaky");
		model.addAttacker(Sneaky);
		Attacker Noisy = new Attacker ("Noisy");
		model.addAttacker(Noisy);
		
		/////////////////////////////
		////Defense Effectiveness////
		/////////////////////////////
		model.setDefenseEffectivenesss(model.getAttackers(), Arrays.asList(A12),M12,0.5);
		model.setDefenseEffectivenesss(model.getAttackers(), Arrays.asList(A1),M1,0.6);
		model.setDefenseEffectivenesss(model.getAttackers(), Arrays.asList(A2),M2,0.5);
		
		///////////////
		////Actions////
		///////////////
		NormalAction skip = new NormalAction("skip");
		model.addNormalAction(skip);
		
		//////////////////////////////
		////Attack Detection Rates////
		//////////////////////////////
		A12.setDetectionRate(0.8);
		A1.setDetectionRate(0.5);
		A2.setDetectionRate(0.7);
		
		////////////////////////////////
		////Quantitative Constraints////
		////////////////////////////////
		
		//////////////////////////
		////Action Constraints////
		//////////////////////////
		
		///////////////////////
		////Attack Diagrams////
		///////////////////////
		ProcessState START = new ProcessState("START");
		model.setInitialState(START);
		ProcessState ATTACK = new ProcessState("ATTACK");
		START.addTransition(new ProcessTransition(2.0,skip,ATTACK,new SideEffect[]{},new TrueConstraint()));
		START.addTransition(new ProcessTransition(98.0,skip,START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A2),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A1),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A12),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(G),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A1),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A111),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A112),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A1121),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A1122),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(A1123),START,new SideEffect[]{},new TrueConstraint()));
		ATTACK.addTransition(new ProcessTransition(1.0,new AddAction(OR1),START,new SideEffect[]{},new TrueConstraint()));
		
		///////////////////////
		////Initial Attacks////
		///////////////////////
		model.init(Random,Arrays.asList());
		
		return model;
	}
}
